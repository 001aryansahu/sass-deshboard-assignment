import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth'

export default function Login(){
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState(null)
  const { login } = useAuth()
  const navigate = useNavigate()

  const submit = async (e) => {
    e.preventDefault()
    const res = login({ username, password })
    if(res.ok) return navigate('/')
    setError(res.message)
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md bg-white p-8 rounded-2xl shadow">
        <h2 className="text-2xl font-semibold mb-6">Sign in</h2>
        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="block text-sm">Username</label>
            <input value={username} onChange={e=>setUsername(e.target.value)} className="mt-1 w-full p-2 border rounded" />
          </div>
          <div>
            <label className="block text-sm">Password</label>
            <input type="password" value={password} onChange={e=>setPassword(e.target.value)} className="mt-1 w-full p-2 border rounded" />
          </div>
          {error && <div className="text-red-600">{error}</div>}
          <button className="w-full py-2 rounded bg-indigo-600 text-white">Login</button>
          <div className="text-xs text-gray-500 mt-2">Hint: password is <code>test123</code></div>
        </form>
      </div>
    </div>
  )
}